/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LENOVO
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ATMPINConfirmclass extends JFrame {
    private final JTextField pinField; // PIN input field
    private final JTextField cardField; // Card number input field
    private String pin = "";

    public ATMPINConfirmclass() {
        // Frame title and layout
        setTitle("ATM");
        setLayout(new BorderLayout());

        // Top panel for title
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("ATM - Simple and Easy to Use"));
        add(topPanel, BorderLayout.NORTH);

        // Center panel for PIN and card entry
        JPanel centerPanel = new JPanel(new GridLayout(2, 1));
        pinField = new JTextField(10);
        cardField = new JTextField(16);

        pinField.setEditable(false);
        centerPanel.add(new JLabel("Enter PIN:"));
        centerPanel.add(pinField);
        centerPanel.add(new JLabel("Enter Card #:"));
        centerPanel.add(cardField);
        add(centerPanel, BorderLayout.CENTER);

        // Button panel for number pad
        JPanel buttonPanel = new JPanel(new GridLayout(4, 3));
        String[] buttons = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Clear", "Enter"};

        for (String text : buttons) {
            JButton button = new JButton(text);
            buttonPanel.add(button);

            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    handleButtonPress(text);
                }
            });
        }
        add(buttonPanel, BorderLayout.SOUTH);

        // Frame settings
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void handleButtonPress(String text) {
        switch (text) {
            case "Clear":
                pin = "";
                pinField.setText("");
                break;
            case "Enter":
                JOptionPane.showMessageDialog(this, "PIN Entered: " + pin);
                pin = ""; // Reset PIN after entry
                pinField.setText("");
                break;
            default:
                if (pin.length() < 4) { // Limit PIN to 4 digits
                    pin += text;
                    pinField.setText(pin);
                }   break;
        }
    }

    public static void main(String[] args) {
        new ATMPINConfirmclass();
    }
}
    
