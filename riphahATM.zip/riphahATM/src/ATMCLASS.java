package com.mycompany.home;
public class ATM {
    private String atmId;

    public ATM(String atmId) {
        this.atmId = atmId;
    }

    public void performTransaction(Customer customer, int enteredPin, double amount, String transactionType) {
        if (customer.getPin() == enteredPin) {
            if (transactionType.equalsIgnoreCase("withdraw")) {
                if (customer.withdraw(amount)) {
                    System.out.println("Withdrawal successful! Amount: " + amount);
                    System.out.println("Remaining Balance: " + customer.getBalance());
                } else {
                    System.out.println("Insufficient balance!");
                }
            } else if (transactionType.equalsIgnoreCase("deposit")) {
                customer.deposit(amount);
                System.out.println("Deposit successful! Amount: " + amount);
                System.out.println("New Balance: " + customer.getBalance());
            } else {
                System.out.println("Invalid transaction type.");
            }
        } else {
            System.out.println("Invalid PIN!");
        }
    }

}
