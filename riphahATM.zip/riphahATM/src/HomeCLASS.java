package com.mycompany.home;
public class Home {

    public static void main(String[] args) {
        Customer customer = new Customer(
            "67676-6767676-6", 
            "Warda", 
            5000.00, 
            1234, 
            "001122334455", 
            "8888 3333 3332 3333"
        );

        // Create an ATM instance
        ATM atm = new ATM("ATM-001");

        // Create a bank account for the customer
        BankAccount account = new BankAccount(customer);

        // Display initial account details
        System.out.println("Initial Account Details:");
        account.displayAccountDetails();
        System.out.println();

        // Perform a withdrawal
        System.out.println("Performing Withdrawal...");
        atm.performTransaction(customer, 1234, 2000.00, "withdraw");
        System.out.println();

        // Perform a deposit
        System.out.println("Performing Deposit...");
        atm.performTransaction(customer, 1234, 3000.00, "deposit");
        System.out.println();

        // Try an invalid PIN
        System.out.println("Attempting Transaction with Invalid PIN...");
        atm.performTransaction(customer, 9999, 1000.00, "withdraw");
        System.out.println();

        // Display final account details
        System.out.println("Final Account Details:");
        account.displayAccountDetails();
    }
}
    

